function startLoveCounter() {
  const counterDiv = document.getElementById("counter");
  const startDate = new Date("2025-05-17T00:00:00");
  setInterval(() => {
    const now = new Date();
    const diff = now - startDate;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const minutes = Math.floor((diff / (1000 * 60)) % 60);
    const seconds = Math.floor((diff / 1000) % 60);
    counterDiv.innerHTML = `Estamos juntos há:<br><strong>${days}</strong> dias, <strong>${hours}</strong> horas, <strong>${minutes}</strong> minutos e <strong>${seconds}</strong> segundos 💖`;
  }, 1000);
}
